#ifndef GRAPH_H
#define GRAPH_H

// Function prototypes
void initializeGraph(int numVertices);
void addEdge(int src, int dest);
void printGraph(int numVertices);

#endif
